import React, { useState, useEffect } from "react";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";
import MessageList from "./components/messageLis";
import InputArea from "./components/inputArea";
import FeedbackModal from "./components/feedbackModal";

const App: React.FC = () => {
  const [messages, setMessages] = useState<
    { text: string; isUser: boolean; file?: File | null }[]
  >([]);
  const [input, setInput] = useState<string>("");
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string>("");
  const [currentMessageIndex, setCurrentMessageIndex] = useState<number | null>(
    null
  );
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [clearFile, setClearFile] = useState<boolean>(false);

  const {
    transcript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition,
  } = useSpeechRecognition();

  useEffect(() => {
    setInput(transcript);
  }, [transcript]);

  const handleSend = async () => {
    if (input.trim() || selectedFile) {
      const newMessage = { text: input, isUser: true, file: selectedFile };
      setMessages([...messages, newMessage]);
      setInput("");
      setSelectedFile(null);
      setClearFile(true);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSend();
    }
  };

  const handleVoiceInput = () => {
    if (listening) {
      SpeechRecognition.stopListening();
    } else {
      resetTranscript();
      SpeechRecognition.startListening();
    }
  };

  const handlePlayAudio = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(utterance);
  };

  const openFeedbackModal = (index: number) => {
    setCurrentMessageIndex(index);
    setIsModalOpen(true);
  };

  const closeFeedbackModal = () => {
    setIsModalOpen(false);
    setFeedback("");
  };

  const submitFeedback = () => {
    if (currentMessageIndex !== null) {
      closeFeedbackModal();
    }
  };

  const handleFileSelect = (file: File | null) => {
    setSelectedFile(file);
    setClearFile(false);
  };

  const exportChat = () => {
    const chatData = JSON.stringify(messages, null, 2);
    const blob = new Blob([chatData], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "chat_export.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!browserSupportsSpeechRecognition) {
    return <span>Browser doesn't support speech recognition.</span>;
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50 p-2 sm:p-4">
      <header className="flex justify-between items-center p-4 bg-gray-500 text-white">
        <h1 className="text-xl font-bold">Query Crafter</h1>
        <button
          onClick={exportChat}
          className="bg-blue-900 text-white px-4 py-2 rounded-lg shadow hover:bg-blue-800"
        >
          Export Chat
        </button>
      </header>
      <MessageList
        messages={messages}
        onOpenFeedbackModal={openFeedbackModal}
        onPlayAudio={handlePlayAudio}
      />
      <InputArea
        input={input}
        onInputChange={handleInputChange}
        onKeyPress={handleKeyPress}
        onSend={handleSend}
        onVoiceInput={handleVoiceInput}
        listening={listening}
        onFileSelect={handleFileSelect}
        clearFile={clearFile}
      />
      <FeedbackModal
        isOpen={isModalOpen}
        feedback={feedback}
        onClose={closeFeedbackModal}
        onSubmit={submitFeedback}
        onFeedbackChange={(e) => setFeedback(e.target.value)}
      />
    </div>
  );
};

export default App;
