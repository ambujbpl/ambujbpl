export const detectIntent = (message: string): string => {
  // Mock intent detection logic
  if (message.toLowerCase().includes("hello")) {
    return "greeting";
  }
  return "unknown";
};

export const analyzeSentiment = (message: string): string => {
  // Mock sentiment analysis logic
  if (message.toLowerCase().includes("happy")) {
    return "positive";
  } else if (message.toLowerCase().includes("sad")) {
    return "negative";
  }
  return "neutral";
};
