export const fetchResponse = (query: string): string => {
  // Mock response logic
  if (query.toLowerCase().includes("weather")) {
    return "The weather is sunny.";
  }
  return "I am not sure about that. Let me find out.";
};
