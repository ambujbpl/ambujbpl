import Tesseract from "tesseract.js";

export const scanDocument = async (file: File): Promise<string> => {
  const {
    data: { text },
  } = await Tesseract.recognize(file, "eng");
  return text;
};
