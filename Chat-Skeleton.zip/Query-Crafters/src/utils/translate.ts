export const translateText = async (
  text: string,
  targetLang: string
): Promise<string> => {
  // Mock translation logic
  if (targetLang === "es") {
    return "Hola, ¿cómo estás?";
  }
  return text;
};
