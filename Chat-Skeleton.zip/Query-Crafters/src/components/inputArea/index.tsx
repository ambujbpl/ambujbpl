import InputArea from "./InputArea";

export default InputArea;