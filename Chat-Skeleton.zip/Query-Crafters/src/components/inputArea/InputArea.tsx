import React, { useState, useEffect } from "react";
import {
  FaMicrophone,
  FaPaperPlane,
  FaPaperclip,
  FaFileAlt,
  FaTimes,
} from "react-icons/fa";

interface InputAreaProps {
  input: string;
  onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onKeyPress: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  onSend: () => void;
  onVoiceInput: () => void;
  listening: boolean;
  onFileSelect: (file: File | null) => void;
  clearFile: boolean;
}

const InputArea: React.FC<InputAreaProps> = ({
  input,
  onInputChange,
  onKeyPress,
  onSend,
  onVoiceInput,
  listening,
  onFileSelect,
  clearFile,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  useEffect(() => {
    if (clearFile) {
      setSelectedFile(null);
    }
  }, [clearFile]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files ? e.target.files[0] : null;
    setSelectedFile(file);
    onFileSelect(file);
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    onFileSelect(null);
  };

  return (
    <div className="relative flex items-center p-4 border-t bg-white sticky bottom-0 shadow-lg">
      <div className="absolute left-8 flex items-center h-full">
        <FaMicrophone
          onClick={onVoiceInput}
          className={`cursor-pointer text-lg ${
            listening ? "text-red-500" : "text-gray-500"
          } hover:text-gray-700`}
        />
      </div>
      <div className="absolute left-16 border-l h-10 border-gray-800"></div>
      <div className="absolute left-20 flex items-center h-full">
        <label
          htmlFor="file-upload"
          className="cursor-pointer text-lg text-gray-500 hover:text-gray-700"
        >
          <FaPaperclip />
        </label>
        <input
          id="file-upload"
          type="file"
          className="hidden"
          onChange={handleFileChange}
        />
      </div>
      <input
        type="text"
        value={input}
        onChange={onInputChange}
        onKeyPress={onKeyPress}
        className="flex-1 p-4 pl-24 border rounded-lg text-lg shadow pr-16"
        placeholder="Type a message..."
      />
      {selectedFile && (
        <div className="absolute left-20 flex items-center space-x-2 bg-gray-100 p-2 rounded-lg shadow">
          <FaFileAlt className="text-gray-500" />
          <span className="text-sm text-gray-700">{selectedFile.name}</span>
          <FaTimes
            className="text-gray-500 cursor-pointer hover:text-gray-700"
            onClick={handleRemoveFile}
          />
        </div>
      )}
      <button
        onClick={onSend}
        className="absolute right-4 h-16 w-16 p-2 bg-blue-900 text-white rounded-lg flex items-center justify-center text-lg shadow hover:bg-blue-800 cursor-pointer"
      >
        <FaPaperPlane />
      </button>
    </div>
  );
};

export default InputArea;
