import React from "react";
import {
  FaThumbsUp,
  FaThumbsDown,
  FaVolumeUp,
  FaUser,
  FaRobot,
  FaFileAlt,
} from "react-icons/fa";

interface Message {
  text: string;
  isUser: boolean;
  file?: File | null;
}

interface MessageListProps {
  messages: Message[];
  onOpenFeedbackModal: (index: number) => void;
  onPlayAudio: (text: string) => void;
}

const MessageList: React.FC<MessageListProps> = ({
  messages,
  onOpenFeedbackModal,
  onPlayAudio,
}) => {
  return (
    <div className="flex flex-col flex-1 overflow-y-auto p-2 sm:p-4 bg-white rounded-lg shadow-lg space-y-4">
      {messages.map((message, index) => (
        <div
          key={index}
          className={`flex ${
            message.isUser ? "justify-end" : "justify-start"
          } mb-4`}
        >
          <div className="flex items-start space-x-2">
            {message.isUser ? (
              <FaUser className="text-blue-900 mt-6 text-2xl" />
            ) : (
              <FaRobot className="text-blue-800 mt-6 text-2xl" />
            )}
            <div
              className={`relative max-w-4xl p-6 rounded-lg shadow ${
                message.isUser ? "bg-gray-300 text-black" : "bg-gray-100"
              }`}
            >
              <span>{message.text}</span>
              {message.file && (
                <div className="mt-2 flex items-center space-x-2">
                  <FaFileAlt className="text-gray-500" />
                  <span className="text-sm text-gray-700">
                    {message.file.name}
                  </span>
                </div>
              )}
              <div className="absolute bottom-1 right-1 flex space-x-1">
                <button
                  className="text-blue-900 hover:text-blue-800 cursor-pointer"
                  onClick={() => onOpenFeedbackModal(index)}
                >
                  <FaThumbsUp />
                </button>
                <button
                  className="text-blue-900 hover:text-blue-800 cursor-pointer"
                  onClick={() => onOpenFeedbackModal(index)}
                >
                  <FaThumbsDown />
                </button>
                <button
                  className="text-blue-900 hover:text-blue-800 cursor-pointer"
                  onClick={() => onPlayAudio(message.text)}
                >
                  <FaVolumeUp />
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MessageList;
