import FeedbackModal from "./FeedbackModal";

export default FeedbackModal;