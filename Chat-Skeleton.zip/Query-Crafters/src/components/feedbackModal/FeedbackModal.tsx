import React from "react";

interface FeedbackModalProps {
  isOpen: boolean;
  feedback: string;
  onClose: () => void;
  onSubmit: () => void;
  onFeedbackChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
}

const FeedbackModal: React.FC<FeedbackModalProps> = ({
  isOpen,
  feedback,
  onClose,
  onSubmit,
  onFeedbackChange,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-25">
      <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg mx-4 sm:mx-auto">
        <h2 className="text-lg font-semibold mb-4">Provide Feedback</h2>
        <textarea
          value={feedback}
          onChange={onFeedbackChange}
          className="w-full p-2 border rounded-lg mb-4"
          placeholder="Type your feedback here..."
        />
        <div className="flex justify-end space-x-2">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-300 rounded-lg hover:bg-gray-400"
          >
            Cancel
          </button>
          <button
            onClick={onSubmit}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
};

export default FeedbackModal;
